Compiler with CodeBlocks
HidDemo.cbp is project , it can be opened by codeblocks
The usb you need set as below
sudo chmod 666 /dev/bus/usb/001/00*

������USBȨ��
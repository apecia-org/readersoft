//warning:
//if you want to debug,  open qtcreator as below
//sudo qtcreator ,  or can not use serial port in debug mode

//if you develop raspberry or X86 or X64 usb or Net soft,
//please refer to RasbianPI or linux code

//

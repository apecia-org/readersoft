//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ScanDevice.rc
//
#define IDD_SCANDEVICE_DIALOG           102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_SET                  129
#define IDC_LIST1                       1000
#define IDC_LIST_READERS                1000
#define IDC_BTN_START                   1001
#define IDC_EDIT_SN                     1002
#define IDC_BTN_START2                  1002
#define IDC_BTN_SET                     1002
#define IDC_EDIT_MACADDR                1003
#define IDC_IPADDRESS1                  1004
#define IDC_IPADDRESS2                  1005
#define IDC_IPADDRESS3                  1006
#define IDC_IPADDRESS4                  1007
#define IDC_EDIT3                       1008
#define IDC_EDIT4                       1009
#define IDC_CHECK1                      1010
#define IDC_CHECK2                      1011
#define IDC_EDIT5                       1012
#define IDC_EDIT6                       1013
#define IDC_EDIT7                       1014
#define IDC_EDIT8                       1015
#define IDC_EDIT9                       1016
#define IDC_BUTTON1                     1017
#define IDC_BUTTON2                     1018
#define IDC_EDIT_SETTIME                1019
#define IDC_BUTTON3                     1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ReaderDemo.rc
//
#define IDD_READERDEMO_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDC_COMBO1                      1000
#define IDC_BUTTON_OPEN                 1001
#define IDC_BUTTON_CLOSE                1002
#define IDC_EDIT1                       1003
#define IDC_BUTTON10                    1011
#define IDC_BUTTON11                    1012
#define IDC_BUTTON12                    1013
#define IDC_BUTTON1                     1014
#define IDC_BUTTON13                    1015
#define IDC_BUTTON2                     1015
#define IDC_BUTTON14                    1016
#define IDC_BUTTON3                     1017
#define IDC_BUTTON4                     1018
#define IDC_COMBO2                      1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WindowsApplication1")]
[assembly: AssemblyDescription("Test")]
[assembly: AssemblyConfiguration("Test")]
[assembly: AssemblyCompany("Test")]
[assembly: AssemblyProduct("WindowsApplication1")]
[assembly: AssemblyCopyright("(C) Test 2012")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("dda40544-801e-45a4-861f-9da8f4635e5a")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

Compiler with CodeBlocks
ComDemo.cbp is project , it can be opened by codeblocks
The com you need set as below
sudo chmod 666 /dev/ttyUSB0
sudo chmod 666 /dev/ttyS0

������ComȨ��
sudo chmod 666 /dev/ttyUSB0
sudo chmod 666 /dev/ttyS0